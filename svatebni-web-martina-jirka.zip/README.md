# Svatební web – Martina & Jirka

Tento balíček obsahuje statický web připravený pro **GitHub Pages**.

## Struktura
- `index.html` – hlavní stránka
- `hero.jpg` – úvodní fotografie

## Jak publikovat na GitHub Pages (2 minuty)
1. Vytvoř si účet na https://github.com (pokud ještě nemáš).
2. Klikni **New → Create a new repository**.
   - *Repository name:* `svatba` (nebo libovolně)
   - **Public** (kvůli Pages)
3. Otevři nové repo a klikni **Add file → Upload files**.
4. Nahraj soubory `index.html` a `hero.jpg` (z tohoto ZIPu), klikni **Commit changes**.
5. V repo přejdi do **Settings → Pages**.
   - *Build and deployment → Source:* vyber **Deploy from a branch**
   - *Branch:* vyber **main** a složku **/** (root), ulož.
6. Za chvíli se zobrazí adresa ve formátu  
   `https://tvuj-ucet.github.io/svatba/`

## Jak změnit texty
- Otevři `index.html` a uprav texty (jména, program, FAQ…).
- Odkaz na RSVP je zde: `https://forms.gle/syRW1Lke6VbTeKEi9` – případně nahraď za tvůj.

## Tipy
- Pro vlastní doménu (např. `martinaajirka.cz`) nastav v repo **Settings → Pages → Custom domain**.
- Fotky do galerie přidej do stejné složky a v `index.html` přidej nové `<img src="...">`.
